#include <GSM3MobileAccessProvider.h>

GSM3MobileAccessProvider* theGSM3MobileAccessProvider;